﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZipExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Zip Car the not so cheap alternative to havin a car on campus");
            Console.WriteLine("Bobby McKenna");
        }
    }
}
