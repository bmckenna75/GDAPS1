﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//**********************************
// Inventory class
// Will contain a list of Item objects
//**********************************

namespace _105_FinalPracticalStarter
{
    class Inventory
    {
        // Add any necessary fields here


        // Constructor
        public Inventory()
        {
			// *** Implement this constructor ***
		}

		// Methods
		// These have been declared for you already.
		// All methods already include any necessary parameters.
		// See the practical documentation for more detailed information.

		// Adds an item to the inventory as long as it would not exceed
		// the inventory's total weight capacity.
		public bool AddItem(Item itemToAdd)
		{
			// *** Implement this method ***
			// Move or change the following line if necessary
			return false;
		}

		// Repairs weapons (and only weapons) in the inventory
		public void RepairAllWeapons()
		{
			// *** Implement this method ***
		}

		// Prints out each and every item in the inventory
		public void PrintAllItems()
		{
			// *** Implement this method ***
		}

		// Prints out weapons (and only weapons) in the inventory
		public void PrintAllWeapons()
		{
			// *** Implement this method ***
		}

		// Loads items from the file with the given name, 
		// and adds them to the inventory
		public void ReadData(string filename)
        {
			// *** Implement this method ***
		}

		// Searches the inventory for an item with the specified name
        public Item Search(string itemName)
        {
			// *** Implement this method ***
			// Move or change the following line if necessary
			return null;
        }
        
		// Returns the first item in the inventory (if it exists)
        public Item GetFirstItem()
        {
			// *** Implement this method ***
			// Move or change the following line if necessary
			return null;
        }
        
		
	}
}
